package com.example.getman.ui.main.model

import java.util.Date

data class HistoryRequest(
    val date: Date,
    val request: RequestModel
)

sealed interface HistoryType {
    data class HistoryDate(val date: Date): HistoryType
    data class HistoryRequest(val request: RequestModel): HistoryType
}
