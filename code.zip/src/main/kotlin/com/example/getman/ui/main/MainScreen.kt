package com.example.getman.ui.main

import com.example.getman.GetManApplication
import com.example.getman.base.Screen
import com.example.getman.ui.main.adapter.HistoryRequestTreeCell
import com.example.getman.ui.main.model.HistoryType
import com.example.getman.ui.main.model.RequestModel
import com.example.getman.utils.RequestEnum
import javafx.beans.property.SimpleStringProperty
import javafx.collections.FXCollections
import javafx.scene.control.*
import javafx.scene.control.cell.PropertyValueFactory
import javafx.scene.image.Image
import javafx.scene.image.ImageView
import javafx.stage.FileChooser
import org.koin.core.inject
import java.io.File
import java.util.*

class MainScreen : Screen() {

    lateinit var btnChooseFile: Button
    lateinit var testGenTable: TableView<Map<String, String>>
    lateinit var ivTestGen: ImageView
    lateinit var testGenTab: Tab
    lateinit var collectionTree: TreeView<String>
    lateinit var treeView: TreeView<HistoryType>
    lateinit var ivHistory: ImageView
    lateinit var ivCollection: ImageView
    lateinit var historyTab: Tab
    lateinit var collectionTab: Tab
    lateinit var addButton: Tab
    lateinit var tabPane: TabPane
    override val viewModel by inject<MainViewModel>()
    private var tabCount = 0

    override fun onCreate() {
        super.onCreate()
        initViews()
        initListeners()
    }

    private fun initViews() {
        createNewTab()
        val image = Image("ic_collection.png")
        ivCollection.image = image
        val historyImage = Image("ic_history.png")
        ivHistory.image = historyImage
        val testGenImage = Image("ic_analysis.png")
        ivTestGen.image = testGenImage

        val rootItem: TreeItem<HistoryType> = TreeItem()
        val webItem: TreeItem<HistoryType> = TreeItem(HistoryType.HistoryDate(Date()))
        repeat(20) {
            webItem.children.add(
                TreeItem(
                    HistoryType.HistoryRequest(
                        RequestModel(
                            requestType = RequestEnum.GET,
                            url = "https://www.turais.de/how-to-custom-listview-cell-in-javafx/",
                        )
                    )
                )
            )
        }
        rootItem.children.add(webItem)

        val javaItem: TreeItem<HistoryType> = TreeItem(HistoryType.HistoryDate(Date()))
        repeat(20) {
            javaItem.children.add(
                TreeItem(
                    HistoryType.HistoryRequest(
                        RequestModel(
                            requestType = RequestEnum.GET,
                            url = "https://www.turais.de/how-to-custom-listview-cell-in-javafx/",
                        )
                    )
                )
            )
        }
        rootItem.children.add(javaItem)

        treeView.root = rootItem
        treeView.isShowRoot = false
        treeView.setCellFactory {
            HistoryRequestTreeCell {

            }
        }

        val rootCollection: TreeItem<String> = TreeItem()
        val webItem2: TreeItem<String> = TreeItem("Collection 1")
        repeat(20) {
            webItem2.children.add(TreeItem("GET https://jenkov.com/tutorials/javafx/treeview.html"))
        }
        rootCollection.children.add(webItem2)

        val javaItem2: TreeItem<String> = TreeItem("Collection 2")

        repeat(20) {
            javaItem2.children.add(TreeItem("POST https://jenkov.com/tutorials/javafx/treeview.html"))
        }
        rootCollection.children.add(javaItem2)

        collectionTree.root = rootCollection
        collectionTree.isShowRoot = false
    }

    private fun initListeners() {
        tabPane.selectionModel.selectedItemProperty().addListener { _, _, newTab ->
            if (newTab == addButton) {
                createNewTab()
            }
        }
        btnChooseFile.setOnAction {
            val fileChooser = FileChooser()
            fileChooser.title = "Open Resource File"
            val file = fileChooser.showOpenDialog(GetManApplication.instance.primaryStage)
            if (file != null) {
                try {
                    val testcases = viewModel.generateTestcases(file.absolutePath)
                    testGenTable.items = FXCollections.observableArrayList(testcases)
                    testGenTable.columns.clear()
                    testcases[0].forEach {
                        val column1 = TableColumn<Map<String, String>, String>(it.key)
                        column1.setCellValueFactory { param -> SimpleStringProperty(param.value[it.key]) }
                        testGenTable.columns.add(column1)
                    }
                } catch (e: Exception) {
                    Alert(Alert.AlertType.ERROR).apply {
                        title = "Error"
                        contentText = "Invalid file format"
                    }.show()
                }
            }
        }
    }

    private fun createNewTab() {
        val fxmlLoader = GetManApplication.instance.loadFxml("new-tab.fxml")
        val newTab = fxmlLoader.load<Tab>()
        tabPane.tabs.add(tabCount++, newTab)
        tabPane.selectionModel.select(newTab)
        newTab.setOnCloseRequest {
            if (tabCount == 1) {
                it.consume()
            } else {
                tabCount--
            }
        }
    }

    companion object {
        const val FXML_VIEW_NAME = "main-page.fxml"
    }
}

typealias Constraint = Pair<Pair<String, String>, Pair<String, List<String>>>