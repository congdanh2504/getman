package com.example.getman.ui.main

import com.example.getman.base.ViewModel
import com.example.getman.domain.repository.NetworkRepository
import com.example.getman.utils.RequestEnum
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import okhttp3.RequestBody
import okhttp3.Response
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(private val networkRepository: NetworkRepository) : ViewModel() {

    val response: StateFlow<Response?>

    private val _requestTrigger = MutableSharedFlow<RequestModel>(extraBufferCapacity = Int.MAX_VALUE)

    init {
        response = _requestTrigger.flatMapLatest {
            flow {
                when (it.requestType) {
                    RequestEnum.GET -> emit(networkRepository.get(it.url, it.headers))
                    RequestEnum.POST -> emit(networkRepository.post(it.url, it.body, it.headers))
                    RequestEnum.PUT -> emit(networkRepository.put(it.url, it.body, it.headers))
                    RequestEnum.PATCH -> emit(networkRepository.patch(it.url, it.body, it.headers))
                    RequestEnum.DELETE -> emit(networkRepository.delete(it.url, it.headers))
                    RequestEnum.HEAD -> emit(networkRepository.delete(it.url, it.headers))
                    RequestEnum.OPTION -> emit(networkRepository.options(it.url, it.headers))
                }
            }.catch {
                println("Error: ${it.message}")
            }
        }.stateIn(viewModelScope, SharingStarted.Lazily, null)
    }

    fun request(request: RequestModel) = _requestTrigger.tryEmit(request)

    fun generateTestcases(filename: String): List<Map<String, String>> {
        val parameters = mutableMapOf<String, List<String>>()
        val constraints: MutableList<Constraint> = mutableListOf()
        File(filename).forEachLine {
            if (it.startsWith("IF")) {
                val parts = it.split("IF ", " = ", " THEN ", " = ")

                val firstKey = parts[1].replace("[", "").replace("]", "")
                val firstValue = parts[2].replace("\"", "")
                val secondKey = parts[3].replace("[", "").replace("]", "")
                val secondValue = parts[4].replace("{", "").replace("}", "").split(", ")

                if (!parameters[firstKey]!!.contains(firstValue)) {
                    throw Exception()
                }

                secondValue.forEach { value ->
                    if (!parameters[secondKey]!!.contains(value)) {
                        throw Exception()
                    }
                }

                val constraint: Constraint = Pair(Pair(firstKey, firstValue), Pair(secondKey, secondValue))
                constraints.add(constraint)
                return@forEachLine
            }
            val splitKeyValue = it.split(": ")
            val key = splitKeyValue[0]
            val value = splitKeyValue[1].split(", ")
            parameters[key] = value
        }

        val testCases: List<Map<String, String>> = generateTestCases(parameters)

        val newTest: List<Map<String, String>> = testCases.mapNotNull { test ->
            constraints.forEach { constraint ->
                if (test[constraint.first.first] == constraint.first.second) {
                    if (!constraint.second.second.contains(test[constraint.second.first])) {
                        return@mapNotNull null
                    }
                }
            }
            test
        }
        return newTest
    }

    private fun generateTestCases(parameters: Map<String, List<String>>): List<Map<String, String>> {
        val testCases = mutableListOf<Map<String, String>>()
        generateTestCasesHelper(parameters, mutableMapOf(), testCases)
        return testCases
    }

    private fun generateTestCasesHelper(
        parameters: Map<String, List<String>>,
        current: MutableMap<String, String>,
        testCases: MutableList<Map<String, String>>
    ) {
        if (current.size == parameters.size) {
            testCases.add(current.toMap())
            return
        }

        for ((key, value) in parameters) {
            if (!current.containsKey(key)) {
                for (v in value) {
                    current[key] = v
                    generateTestCasesHelper(parameters, current, testCases)
                    current.remove(key)
                }
                break
            }
        }
    }
}

data class RequestModel(
    val requestType: RequestEnum,
    val url: String,
    val headers: Map<String, String>,
    val body: RequestBody
)