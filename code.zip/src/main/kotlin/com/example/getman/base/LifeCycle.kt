package com.example.getman.base

interface LifeCycle {
    fun onCreate()
    fun onDestroy()
}