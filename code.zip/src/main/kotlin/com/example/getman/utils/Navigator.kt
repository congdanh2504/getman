package com.example.getman.utils

interface Navigator {
    fun navigateToLogin()
    fun navigateToHome()
    fun navigateToRegister()
}