package com.example.getman.utils

enum class BodyEnum {
    NONE, FORM_DATA, JSON
}