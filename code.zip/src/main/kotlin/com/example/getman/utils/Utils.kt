package com.example.getman.utils

import com.example.getman.GetManApplication

val applicationScope = GetManApplication.instance.applicationScope